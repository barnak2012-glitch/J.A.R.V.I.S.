"""3D model generation for JARVIS.

Claude designs a model as a list of primitive parts (box, sphere, cylinder, cone, pyramid, capsule);
this module assembles them with trimesh and exports GLB / STL / OBJ plus an interactive HTML viewer.
Without an API key, a few built-in presets are used.
"""
import os
import re
import math
import base64

import numpy as np
import trimesh
from trimesh import transformations as T

OUT = os.path.join(os.path.expanduser("~"), "Documents", "Jarvis_Output", "3D")
os.makedirs(OUT, exist_ok=True)

PROMPT = (
    'Design a detailed 3D model of "{what}" using ONLY primitive parts. '
    "Y axis is UP. The model should fit roughly within 2 units. Use 15-50 parts for good detail, "
    "sensible colors, and place parts so they touch/overlap correctly. Return JSON: "
    '{{"name": str, "parts": [{{"shape": "box|sphere|cylinder|cone|pyramid|capsule", '
    '"size": [x, y, z], "position": [x, y, z], "rotation": [rx, ry, rz in degrees], '
    '"color": [r, g, b 0-255]}}]}}. '
    "For box/sphere/cylinder/cone/capsule, size is the full width/height/depth (cylinder, cone and capsule "
    "have their axis along Y, so size[1] is the length; size[0] and size[2] are diameters). "
    "For pyramid, size is [base width, height, base depth]."
)


def P(shape, size, pos, color, rot=(0, 0, 0)):
    return {"shape": shape, "size": list(size), "position": list(pos),
            "color": list(color), "rotation": list(rot)}


# ------------------------------- built-in presets -------------------------------
def _house():
    return [
        P("box", (2, 1.2, 1.6), (0, 0.6, 0), (232, 212, 172)),
        P("pyramid", (2.5, 0.9, 2.0), (0, 1.65, 0), (170, 60, 50)),
        P("box", (0.35, 0.7, 0.05), (0, 0.35, 0.81), (110, 70, 40)),
        P("box", (0.3, 0.3, 0.05), (-0.6, 0.7, 0.81), (140, 200, 235)),
        P("box", (0.3, 0.3, 0.05), (0.6, 0.7, 0.81), (140, 200, 235)),
        P("box", (0.25, 0.6, 0.25), (0.6, 1.7, -0.3), (150, 90, 80)),
    ]


def _table():
    parts = [P("box", (2, 0.1, 1.2), (0, 1.0, 0), (150, 100, 60))]
    for x in (-0.9, 0.9):
        for z in (-0.5, 0.5):
            parts.append(P("cylinder", (0.12, 1.0, 0.12), (x, 0.5, z), (110, 70, 40)))
    return parts


def _robot():
    g, l = (150, 160, 175), (0, 200, 255)
    return [
        P("box", (0.9, 1.0, 0.6), (0, 1.0, 0), g),
        P("box", (0.6, 0.5, 0.5), (0, 1.8, 0), (180, 190, 205)),
        P("sphere", (0.12, 0.12, 0.12), (-0.15, 1.85, 0.26), l),
        P("sphere", (0.12, 0.12, 0.12), (0.15, 1.85, 0.26), l),
        P("cylinder", (0.05, 0.3, 0.05), (0, 2.2, 0), g),
        P("sphere", (0.1, 0.1, 0.1), (0, 2.4, 0), (230, 50, 50)),
        P("cylinder", (0.18, 0.9, 0.18), (-0.65, 1.0, 0), g),
        P("cylinder", (0.18, 0.9, 0.18), (0.65, 1.0, 0), g),
        P("cylinder", (0.25, 0.7, 0.25), (-0.25, 0.35, 0), g),
        P("cylinder", (0.25, 0.7, 0.25), (0.25, 0.35, 0), g),
        P("box", (0.35, 0.1, 0.5), (-0.25, 0.05, 0.1), (90, 100, 115)),
        P("box", (0.35, 0.1, 0.5), (0.25, 0.05, 0.1), (90, 100, 115)),
        P("sphere", (0.2, 0.2, 0.2), (0, 1.2, 0.31), l),
    ]


def _tree():
    return [
        P("cylinder", (0.3, 1.0, 0.3), (0, 0.5, 0), (110, 75, 45)),
        P("cone", (1.6, 0.9, 1.6), (0, 1.2, 0), (30, 120, 50)),
        P("cone", (1.3, 0.9, 1.3), (0, 1.7, 0), (35, 135, 55)),
        P("cone", (0.9, 0.8, 0.9), (0, 2.2, 0), (40, 150, 60)),
    ]


def _rocket():
    w = (235, 235, 240)
    parts = [
        P("cylinder", (0.7, 2.0, 0.7), (0, 1.2, 0), w),
        P("cone", (0.7, 0.8, 0.7), (0, 2.6, 0), (220, 50, 50)),
        P("sphere", (0.3, 0.3, 0.3), (0, 1.7, 0.3), (120, 200, 240)),
        P("cone", (0.5, 0.4, 0.5), (0, 0.0, 0), (255, 150, 30), (180, 0, 0)),
    ]
    for a in (0, 120, 240):
        x, z = 0.45 * math.sin(math.radians(a)), 0.45 * math.cos(math.radians(a))
        parts.append(P("box", (0.08, 0.7, 0.4), (x, 0.5, z), (220, 50, 50), (0, a, 0)))
    return parts


def _snowman():
    w = (245, 245, 250)
    return [
        P("sphere", (1.2, 1.2, 1.2), (0, 0.6, 0), w),
        P("sphere", (0.9, 0.9, 0.9), (0, 1.5, 0), w),
        P("sphere", (0.65, 0.65, 0.65), (0, 2.15, 0), w),
        P("cone", (0.1, 0.4, 0.1), (0, 2.15, 0.4), (255, 140, 30), (90, 0, 0)),
        P("sphere", (0.08, 0.08, 0.08), (-0.12, 2.25, 0.28), (20, 20, 20)),
        P("sphere", (0.08, 0.08, 0.08), (0.12, 2.25, 0.28), (20, 20, 20)),
        P("cylinder", (0.5, 0.35, 0.5), (0, 2.65, 0), (30, 30, 30)),
    ]


PRESETS = {"house": _house, "home": _house, "table": _table, "robot": _robot, "tree": _tree,
           "rocket": _rocket, "snowman": _snowman}
BASIC = {"cube": "box", "box": "box", "sphere": "sphere", "ball": "sphere",
         "cylinder": "cylinder", "cone": "cone", "pyramid": "pyramid"}


def _preset_for(what):
    w = what.lower()
    for key, fn in PRESETS.items():
        if key in w:
            return {"name": what, "parts": fn()}
    for key, shape in BASIC.items():
        if key in w:
            return {"name": what, "parts": [P(shape, (1.6, 1.6, 1.6), (0, 0.8, 0), (0, 160, 255))]}
    return {"name": what, "parts": _robot(),
            "note": "Without an AI key I only know presets: house, table, robot, tree, rocket, snowman, "
                    "and basic shapes. I made a robot instead."}


# --------------------------------- mesh building --------------------------------
def _make(shape, size, pos, rot, color):
    sx, sy, sz = [max(float(v), 0.001) for v in size]
    to_y = T.rotation_matrix(-math.pi / 2, [1, 0, 0])  # trimesh builds along Z, we want Y-up
    if shape == "sphere":
        m = trimesh.creation.icosphere(subdivisions=2, radius=0.5)
    elif shape == "cylinder":
        m = trimesh.creation.cylinder(radius=0.5, height=1.0, sections=24)
        m.apply_transform(to_y)
    elif shape == "capsule":
        m = trimesh.creation.capsule(height=0.5, radius=0.25)
        m.apply_transform(to_y)
    elif shape in ("cone", "pyramid"):
        m = trimesh.creation.cone(radius=0.5, height=1.0, sections=24 if shape == "cone" else 4)
        m.apply_translation([0, 0, -0.5])
        m.apply_transform(to_y)
        if shape == "pyramid":
            m.apply_transform(T.rotation_matrix(math.pi / 4, [0, 1, 0]))
            sx, sz = sx * math.sqrt(2), sz * math.sqrt(2)
    else:
        m = trimesh.creation.box(extents=[1, 1, 1])
    m.apply_scale([sx, sy, sz])
    ang = [math.radians(float(a)) for a in rot]
    m.apply_transform(T.euler_matrix(ang[0], ang[1], ang[2], "sxyz"))
    m.apply_translation([float(p) for p in pos])
    rgba = [int(max(0, min(255, float(c)))) for c in color[:3]] + [255]
    m.visual.face_colors = np.tile(np.array(rgba, dtype=np.uint8), (len(m.faces), 1))
    return m


def _safe(s):
    return re.sub(r"[^A-Za-z0-9_-]+", "_", s.strip())[:40] or "model"


VIEWER = """<!doctype html><html><head><meta charset="utf-8"><title>{title}</title>
<script type="module" src="https://ajax.googleapis.com/ajax/libs/model-viewer/3.5.0/model-viewer.min.js"></script>
<style>html,body{{margin:0;height:100%;background:radial-gradient(#06304d,#020b16);font-family:Consolas,monospace}}
model-viewer{{width:100%;height:100%}}h1{{position:fixed;top:12px;left:20px;margin:0;color:#00d4ff;font-size:20px;letter-spacing:4px}}
p{{position:fixed;bottom:12px;left:20px;margin:0;color:#1e90ff}}</style></head><body>
<h1>J.A.R.V.I.S. // {title}</h1>
<model-viewer src="data:model/gltf-binary;base64,{b64}" auto-rotate camera-controls shadow-intensity="1" exposure="1.1"></model-viewer>
<p>Drag to rotate, scroll to zoom</p></body></html>"""


def build_model(brain, what):
    data = None
    if brain.online:
        data = brain.generate_json(PROMPT.format(what=what), max_tokens=7000)
    if not data or not data.get("parts"):
        data = _preset_for(what)

    meshes = []
    for p in data["parts"]:
        try:
            meshes.append(_make(p.get("shape", "box"), p.get("size", [1, 1, 1]), p.get("position", [0, 0, 0]),
                                p.get("rotation", [0, 0, 0]), p.get("color", [200, 200, 200])))
        except Exception:
            continue
    if not meshes:
        raise ValueError("the design contained no valid parts")

    # centre and normalise to fit 2 units
    allm = trimesh.util.concatenate(meshes)
    lo, hi = allm.bounds
    centre = (lo + hi) / 2
    scale = 2.0 / max(float((hi - lo).max()), 1e-6)
    for m in meshes:
        m.apply_translation(-centre)
        m.apply_scale(scale)
    combined = trimesh.util.concatenate(meshes)

    name = _safe(what)
    base = os.path.join(OUT, name)
    glb, stl, obj = base + ".glb", base + ".stl", base + ".obj"
    trimesh.Scene(meshes).export(glb)
    combined.export(stl)
    combined.export(obj)
    with open(glb, "rb") as f:
        b64 = base64.b64encode(f.read()).decode()
    html = base + "_viewer.html"
    with open(html, "w", encoding="utf-8") as f:
        f.write(VIEWER.format(title=what.title(), b64=b64))

    edges = combined.edges_unique
    if len(edges) > 1200:
        edges = edges[:: len(edges) // 1200 + 1]
    return {"name": what, "glb": glb, "stl": stl, "obj": obj, "html": html,
            "verts": np.array(combined.vertices, dtype=float), "edges": np.array(edges),
            "note": data.get("note")}
