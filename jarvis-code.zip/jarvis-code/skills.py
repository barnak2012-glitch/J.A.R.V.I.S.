"""System-control skills for JARVIS: apps, volume, screenshots, files, reminders, notes, etc."""
import os
import re
import difflib
import shutil
import subprocess
import platform
import datetime
import urllib.parse

import requests

try:
    import psutil
except Exception:
    psutil = None
try:
    import pyautogui
    pyautogui.PAUSE = 0.05
except Exception:
    pyautogui = None

OUT = os.path.join(os.path.expanduser("~"), "Documents", "Jarvis_Output")
os.makedirs(OUT, exist_ok=True)
SYS = platform.system()


# ---------------------------------- apps ----------------------------------------
_INDEX = None


def _index():
    global _INDEX
    if _INDEX is not None:
        return _INDEX
    idx = {}
    if SYS == "Windows":
        roots = [os.path.join(os.environ.get("ProgramData", ""), "Microsoft", "Windows", "Start Menu", "Programs"),
                 os.path.join(os.environ.get("APPDATA", ""), "Microsoft", "Windows", "Start Menu", "Programs")]
        for root in roots:
            for dp, _, files in os.walk(root):
                for f in files:
                    if f.lower().endswith((".lnk", ".url", ".exe")):
                        idx[os.path.splitext(f)[0].lower()] = os.path.join(dp, f)
    elif SYS == "Darwin":
        for root in ("/Applications", "/System/Applications", os.path.expanduser("~/Applications")):
            if os.path.isdir(root):
                for f in os.listdir(root):
                    if f.endswith(".app"):
                        idx[f[:-4].lower()] = os.path.join(root, f)
    else:
        for root in ("/usr/share/applications", os.path.expanduser("~/.local/share/applications")):
            if os.path.isdir(root):
                for f in os.listdir(root):
                    if f.endswith(".desktop"):
                        idx[f[:-8].lower().replace("-", " ")] = os.path.join(root, f)
    _INDEX = idx
    return idx


def _find_app(name):
    idx = _index()
    if name in idx:
        return idx[name]
    subs = [k for k in idx if name in k]
    if subs:
        return idx[min(subs, key=len)]
    close = difflib.get_close_matches(name, list(idx), n=1, cutoff=0.6)
    return idx[close[0]] if close else None


def list_apps():
    return sorted(_index())


def open_any_app(name, aliases=None):
    """Open any installed app (Start Menu / Applications / .desktop index + fuzzy match)."""
    name = name.strip().lower()
    aliases = aliases or {}
    try:
        if SYS == "Windows":
            if name in aliases:
                subprocess.Popen(f'start "" "{aliases[name]}"', shell=True)
                return True
            path = _find_app(name)
            if path:
                os.startfile(path)
                return True
            exe = shutil.which(name)
            if exe:
                subprocess.Popen([exe])
                return True
            return False
        if SYS == "Darwin":
            path = _find_app(name)
            if path:
                subprocess.Popen(["open", path])
                return True
            return subprocess.run(["open", "-a", name.title()], capture_output=True).returncode == 0
        exe = shutil.which(name) or shutil.which(name.replace(" ", "-"))
        if exe:
            subprocess.Popen([exe])
            return True
        path = _find_app(name)
        if path:
            subprocess.Popen(["gtk-launch", os.path.splitext(os.path.basename(path))[0]])
            return True
    except Exception:
        pass
    return False


_PROTECTED = {"system", "explorer", "svchost", "csrss", "winlogon", "wininit", "services", "lsass",
              "smss", "dwm", "python", "pythonw", "code", "init", "systemd", "launchd", "finder"}


def close_app(name):
    if psutil is None:
        return "Install psutil to close apps."
    name = name.strip().lower()
    me = os.getpid()
    n = 0
    for p in psutil.process_iter(["name", "pid"]):
        try:
            pn = (p.info["name"] or "").lower()
            base = pn.rsplit(".", 1)[0] if pn.endswith(".exe") else pn
            if p.info["pid"] != me and name in pn and base not in _PROTECTED:
                p.terminate()
                n += 1
        except Exception:
            continue
    return f"Closed {n} process{'es' if n != 1 else ''} matching {name}." if n else f"{name} isn't running."


# ------------------------------ sound / display / power -------------------------
def volume(action):
    try:
        if SYS == "Darwin":
            cmds = {"up": "set volume output volume ((output volume of (get volume settings)) + 10)",
                    "down": "set volume output volume ((output volume of (get volume settings)) - 10)",
                    "mute": "set volume output muted not (output muted of (get volume settings))"}
            subprocess.run(["osascript", "-e", cmds[action]])
        elif SYS == "Linux":
            arg = {"up": "10%+", "down": "10%-", "mute": "toggle"}[action]
            subprocess.run(["amixer", "sset", "Master", arg])
        elif pyautogui:
            key, times = {"up": ("volumeup", 5), "down": ("volumedown", 5), "mute": ("volumemute", 1)}[action]
            for _ in range(times):
                pyautogui.press(key)
        return True
    except Exception:
        return False


def brightness(level):
    level = max(0, min(100, int(level)))
    try:
        if SYS == "Windows":
            subprocess.run(["powershell", "-Command",
                            f"(Get-WmiObject -Namespace root/WMI -Class WmiMonitorBrightnessMethods)"
                            f".WmiSetBrightness(1,{level})"], capture_output=True, timeout=15)
        elif SYS == "Linux":
            subprocess.run(["brightnessctl", "set", f"{level}%"], capture_output=True)
        else:
            return False
        return True
    except Exception:
        return False


def power(action):
    try:
        if SYS == "Windows":
            cmd = {"lock": "rundll32.exe user32.dll,LockWorkStation", "shutdown": "shutdown /s /t 5",
                   "restart": "shutdown /r /t 5", "sleep": "rundll32.exe powrprof.dll,SetSuspendState 0,1,0"}[action]
        elif SYS == "Darwin":
            cmd = {"lock": "pmset displaysleepnow", "sleep": "pmset sleepnow",
                   "shutdown": "osascript -e 'tell app \"System Events\" to shut down'",
                   "restart": "osascript -e 'tell app \"System Events\" to restart'"}[action]
        else:
            cmd = {"lock": "loginctl lock-session", "shutdown": "systemctl poweroff",
                   "restart": "systemctl reboot", "sleep": "systemctl suspend"}[action]
        subprocess.Popen(cmd, shell=True)
        return f"Executing {action}."
    except Exception as e:
        return f"Could not {action}: {e}"


# ------------------------------- screen / keyboard / mouse ----------------------
def screenshot():
    if pyautogui is None:
        return None
    path = os.path.join(OUT, "screenshot_" + datetime.datetime.now().strftime("%Y%m%d_%H%M%S") + ".png")
    pyautogui.screenshot().save(path)
    return path


def type_text(text):
    if pyautogui is None:
        return False
    pyautogui.write(text, interval=0.02)
    return True


_KEYMAP = {"control": "ctrl", "windows": "win", "window": "win", "return": "enter", "escape": "esc",
           "delete": "delete", "space": "space", "plus": None}


def press_keys(spec):
    if pyautogui is None:
        return False
    keys = [_KEYMAP.get(k, k) for k in spec.lower().split()]
    keys = [k for k in keys if k]
    if not keys:
        return False
    pyautogui.hotkey(*keys)
    return True


def scroll(direction):
    if pyautogui is None:
        return False
    pyautogui.scroll(600 if direction == "up" else -600)
    return True


def click(double=False):
    if pyautogui is None:
        return False
    pyautogui.click(clicks=2 if double else 1)
    return True


# ------------------------------------ info --------------------------------------
def sys_status():
    if psutil is None:
        return "Install psutil for system status."
    parts = [f"CPU {psutil.cpu_percent(interval=0.5):.0f} percent",
             f"memory {psutil.virtual_memory().percent:.0f} percent used",
             f"disk {psutil.disk_usage(os.path.expanduser('~')).percent:.0f} percent full"]
    b = psutil.sensors_battery() if hasattr(psutil, "sensors_battery") else None
    if b:
        parts.append(f"battery {b.percent:.0f} percent{', charging' if b.power_plugged else ''}")
    return ", ".join(parts) + "."


def weather(city=""):
    try:
        url = "https://wttr.in/" + urllib.parse.quote(city) if city else "https://wttr.in/"
        r = requests.get(url, params={"format": "%l: %C, %t, humidity %h, wind %w"}, timeout=8)
        return r.text.strip()
    except Exception:
        return "I couldn't reach the weather service."


def find_files(query, limit=5):
    query = query.lower().strip()
    home = os.path.expanduser("~")
    found = []
    for folder in ("Documents", "Desktop", "Downloads", "Pictures", "Music", "Videos"):
        root = os.path.join(home, folder)
        for dp, _, files in os.walk(root):
            for f in files:
                if query in f.lower():
                    found.append(os.path.join(dp, f))
                    if len(found) >= limit:
                        return found
    return found


def run_shell(cmd):
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=30)
        out = (r.stdout or r.stderr or "").strip()
        return out[:400] if out else "Command finished."
    except Exception as e:
        return f"Command failed: {e}"


# --------------------------- reminders / notes / messaging ----------------------
_NUM = {"a": 1, "an": 1, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7,
        "eight": 8, "nine": 9, "ten": 10, "fifteen": 15, "twenty": 20, "thirty": 30, "half": 30}


def parse_reminder(t):
    m = re.search(r"remind me (?:in|after) (\d+|[a-z]+) (second|minute|hour)s?(?: to| that| about)?\s*(.*)", t)
    if m:
        msg = m.group(3).strip() or "your reminder"
    else:
        m = re.search(r"(?:set )?(?:a )?timer (?:for|of) (\d+|[a-z]+) (second|minute|hour)s?", t)
        msg = "your timer is up" if m else None
    if not m:
        return None
    n = m.group(1)
    n = int(n) if n.isdigit() else _NUM.get(n)
    if not n:
        return None
    return n * {"second": 1, "minute": 60, "hour": 3600}[m.group(2)], msg


def fmt_secs(s):
    if s >= 3600:
        return f"{s // 3600} hour{'s' if s >= 7200 else ''}"
    if s >= 60:
        return f"{s // 60} minute{'s' if s >= 120 else ''}"
    return f"{s} seconds"


NOTES = os.path.join(OUT, "notes.txt")


def add_note(text):
    with open(NOTES, "a", encoding="utf-8") as f:
        f.write(f"[{datetime.datetime.now():%Y-%m-%d %H:%M}] {text}\n")


def read_notes(last=5):
    if not os.path.exists(NOTES):
        return "You have no notes yet."
    with open(NOTES, encoding="utf-8") as f:
        lines = f.read().strip().splitlines()[-last:]
    return " | ".join(lines) if lines else "You have no notes yet."


def whatsapp_url(number, msg):
    num = re.sub(r"[^\d]", "", number)
    return f"https://wa.me/{num}?text={urllib.parse.quote(msg)}"


def mailto_url(addr, msg):
    return f"mailto:{addr}?subject={urllib.parse.quote('Message from JARVIS')}&body={urllib.parse.quote(msg)}"
