"""
J.A.R.V.I.S. - desktop AI assistant
Run:  python jarvis.py
"""
import os
import re
import sys
import json
import math
import queue
import shutil
import threading
import subprocess
import webbrowser
import datetime
import platform
import urllib.parse
import tkinter as tk
from tkinter import filedialog

import requests

# ----------------------------- optional libraries -----------------------------
try:
    import pyttsx3
except ImportError:
    pyttsx3 = None
try:
    import speech_recognition as sr
except ImportError:
    sr = None
try:
    import anthropic
except ImportError:
    anthropic = None
import time
import pathlib
import skills
try:
    import model3d
except Exception:
    model3d = None
try:
    import voices
except Exception:
    voices = None
try:
    import screen
except Exception:
    screen = None

OUTPUT_DIR = os.path.join(os.path.expanduser("~"), "Documents", "Jarvis_Output")
os.makedirs(OUTPUT_DIR, exist_ok=True)

MODEL = "claude-sonnet-5-5"
SYSTEM_PROMPT = (
    "You are J.A.R.V.I.S., a witty, concise, highly capable personal AI assistant. "
    "Answer in 1-4 short sentences unless asked for detail, because your answers are spoken aloud. "
    "No markdown. If the user uploaded documents, use them when relevant."
)

# ------------------------------- colours / theme ------------------------------
BG = "#020b16"
PANEL = "#06182b"
CYAN = "#00d4ff"
BLUE = "#1e90ff"
DIM = "#0a4a6e"
TEXT = "#bfefff"


# ================================== BRAIN ====================================
class Brain:
    """Answers questions: Claude API if key is set, otherwise web fallback."""

    def __init__(self):
        key = os.environ.get("ANTHROPIC_API_KEY")
        self.client = anthropic.Anthropic(api_key=key) if (anthropic and key) else None
        self.history = []
        self.docs = {}  # filename -> text

    @property
    def online(self):
        return self.client is not None

    def _doc_context(self):
        if not self.docs:
            return ""
        parts = []
        for name, txt in self.docs.items():
            parts.append(f"--- {name} ---\n{txt[:12000]}")
        return "\n\nUploaded documents:\n" + "\n".join(parts)

    def ask(self, question):
        if self.client:
            try:
                self.history.append({"role": "user", "content": question})
                resp = self.client.messages.create(
                    model=MODEL,
                    max_tokens=600,
                    system=SYSTEM_PROMPT + self._doc_context(),
                    messages=self.history[-12:],
                )
                answer = resp.content[0].text.strip()
                self.history.append({"role": "assistant", "content": answer})
                return answer
            except Exception as e:
                return f"My AI core had a problem: {e}. Falling back to web search. " + web_answer(question)
        return web_answer(question)

    def generate_json(self, prompt, max_tokens=3000):
        """Ask the LLM for structured JSON (used for creating documents)."""
        if not self.client:
            return None
        try:
            resp = self.client.messages.create(
                model=MODEL,
                max_tokens=max_tokens,
                system="Reply with ONLY valid JSON, no code fences, no commentary.",
                messages=[{"role": "user", "content": prompt}],
            )
            txt = resp.content[0].text.strip()
            txt = re.sub(r"^```(?:json)?|```$", "", txt, flags=re.M).strip()
            return json.loads(txt)
        except Exception:
            return None


def web_answer(query):
    """Quick answer from DuckDuckGo / Wikipedia without any API key."""
    try:
        r = requests.get(
            "https://api.duckduckgo.com/",
            params={"q": query, "format": "json", "no_html": 1, "skip_disambig": 1},
            timeout=8,
        ).json()
        if r.get("AbstractText"):
            return r["AbstractText"][:500]
        if r.get("Answer"):
            return str(r["Answer"])
    except Exception:
        pass
    try:
        title = urllib.parse.quote(query.strip().replace(" ", "_"))
        s = requests.get(
            f"https://en.wikipedia.org/api/rest_v1/page/summary/{title}", timeout=8
        ).json()
        if s.get("extract"):
            return s["extract"][:500]
    except Exception:
        pass
    webbrowser.open("https://www.google.com/search?q=" + urllib.parse.quote(query))
    return "I couldn't find a direct answer, so I opened Google for you."


# ============================== DOCUMENT READING ==============================
def read_document(path):
    ext = os.path.splitext(path)[1].lower()
    try:
        if ext in (".txt", ".md", ".csv", ".py", ".json", ".log"):
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                return f.read()
        if ext == ".pdf":
            from pypdf import PdfReader
            return "\n".join((p.extract_text() or "") for p in PdfReader(path).pages)
        if ext == ".docx":
            from docx import Document
            return "\n".join(p.text for p in Document(path).paragraphs)
        if ext in (".xlsx", ".xlsm"):
            from openpyxl import load_workbook
            wb = load_workbook(path, data_only=True)
            out = []
            for ws in wb.worksheets:
                out.append(f"[Sheet {ws.title}]")
                for row in ws.iter_rows(values_only=True):
                    out.append(", ".join("" if c is None else str(c) for c in row))
            return "\n".join(out)
        if ext == ".pptx":
            from pptx import Presentation
            out = []
            for i, slide in enumerate(Presentation(path).slides, 1):
                out.append(f"[Slide {i}]")
                for sh in slide.shapes:
                    if sh.has_text_frame:
                        out.append(sh.text_frame.text)
            return "\n".join(out)
    except Exception as e:
        return f"(could not read file: {e})"
    return "(unsupported file type)"


# ============================== DOCUMENT CREATION =============================
def safe_name(s):
    return re.sub(r"[^A-Za-z0-9_-]+", "_", s.strip())[:40] or "Untitled"


def open_file(path):
    try:
        if platform.system() == "Windows":
            os.startfile(path)
        elif platform.system() == "Darwin":
            subprocess.Popen(["open", path])
        else:
            subprocess.Popen(["xdg-open", path])
    except Exception:
        pass


def create_word(brain, topic):
    from docx import Document
    data = brain.generate_json(
        f'Write a well-structured document about "{topic}". JSON format: '
        '{"title": str, "sections": [{"heading": str, "paragraphs": [str, ...]}]}. 4-6 sections.'
    )
    if not data:
        data = {"title": topic.title(), "sections": [
            {"heading": "Introduction", "paragraphs": [f"This document is about {topic}."]},
            {"heading": "Details", "paragraphs": ["Add your content here."]}]}
    doc = Document()
    doc.add_heading(data["title"], 0)
    for sec in data["sections"]:
        doc.add_heading(sec["heading"], 1)
        for p in sec["paragraphs"]:
            doc.add_paragraph(p)
    path = os.path.join(OUTPUT_DIR, f"{safe_name(topic)}.docx")
    doc.save(path)
    return path


def create_excel(brain, topic):
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    data = brain.generate_json(
        f'Create a useful spreadsheet about "{topic}". JSON format: '
        '{"title": str, "headers": [str,...], "rows": [[...],...]}. 8-15 rows, realistic sample data.'
    )
    if not data:
        data = {"title": topic[:30], "headers": ["Item", "Value", "Notes"],
                "rows": [["Example", 1, "Edit me"]]}
    wb = Workbook()
    ws = wb.active
    ws.title = data["title"][:30]
    ws.append(data["headers"])
    for c in ws[1]:
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="1E90FF")
    for r in data["rows"]:
        ws.append(r)
    for col in ws.columns:
        ws.column_dimensions[col[0].column_letter].width = max(len(str(c.value or "")) for c in col) + 3
    path = os.path.join(OUTPUT_DIR, f"{safe_name(topic)}.xlsx")
    wb.save(path)
    return path


def create_ppt(brain, topic):
    from pptx import Presentation
    data = brain.generate_json(
        f'Create a presentation about "{topic}". JSON format: '
        '{"title": str, "subtitle": str, "slides": [{"title": str, "bullets": [str,...]}]}. 6-8 slides.'
    )
    if not data:
        data = {"title": topic.title(), "subtitle": "Created by JARVIS",
                "slides": [{"title": "Overview", "bullets": ["Point one", "Point two"]}]}
    prs = Presentation()
    s = prs.slides.add_slide(prs.slide_layouts[0])
    s.shapes.title.text = data["title"]
    s.placeholders[1].text = data.get("subtitle", "")
    for sl in data["slides"]:
        slide = prs.slides.add_slide(prs.slide_layouts[1])
        slide.shapes.title.text = sl["title"]
        tf = slide.placeholders[1].text_frame
        tf.text = sl["bullets"][0] if sl["bullets"] else ""
        for b in sl["bullets"][1:]:
            tf.add_paragraph().text = b
    path = os.path.join(OUTPUT_DIR, f"{safe_name(topic)}.pptx")
    prs.save(path)
    return path


# ================================= APP LAUNCHER ===============================
WIN_ALIASES = {
    "notepad": "notepad", "calculator": "calc", "calc": "calc", "paint": "mspaint",
    "word": "winword", "excel": "excel", "powerpoint": "powerpnt", "chrome": "chrome",
    "edge": "msedge", "firefox": "firefox", "vs code": "code", "vscode": "code",
    "visual studio code": "code", "cmd": "cmd", "command prompt": "cmd",
    "terminal": "wt", "file explorer": "explorer", "explorer": "explorer",
    "settings": "ms-settings:", "task manager": "taskmgr", "spotify": "spotify",
    "whatsapp": "whatsapp:", "camera": "microsoft.windows.camera:",
}


def open_app(name):
    name = name.strip().lower()
    system = platform.system()
    try:
        if system == "Windows":
            target = WIN_ALIASES.get(name, name)
            subprocess.Popen(f'start "" "{target}"', shell=True)
        elif system == "Darwin":
            subprocess.Popen(["open", "-a", name.title()])
        else:
            exe = shutil.which(name) or shutil.which(name.replace(" ", "-"))
            if not exe:
                return False
            subprocess.Popen([exe])
        return True
    except Exception:
        return False


# ================================ SPEAKER (TTS) ===============================
class Speaker:
    def __init__(self, on_state):
        self.q = queue.Queue()
        self.on_state = on_state
        self.speaking = False
        self.enabled = (voices is not None and voices.available()) or pyttsx3 is not None
        threading.Thread(target=self._worker, daemon=True).start()

    def say(self, text):
        if self.enabled:
            self.q.put(text)

    def clear(self):
        with self.q.mutex:
            self.q.queue.clear()

    def _offline_say(self, text):
        if pyttsx3 is None:
            return
        engine = pyttsx3.init()
        engine.setProperty("rate", 175)
        for v in engine.getProperty("voices"):  # prefer a male voice
            if any(k in v.name.lower() for k in ("david", "male", "george", "daniel", "alex")):
                engine.setProperty("voice", v.id)
                break
        engine.say(text)
        engine.runAndWait()
        engine.stop()

    def _worker(self):
        while True:
            text = self.q.get()
            self.speaking = True
            self.on_state(True)
            try:
                if voices is not None and voices.available():
                    try:
                        voices.speak(text)  # neural / custom voice
                    except Exception:
                        self._offline_say(text)  # no internet etc.
                else:
                    self._offline_say(text)
            except Exception:
                pass
            self.speaking = False
            if self.q.empty():
                self.on_state(False)


# ================================== MAIN UI ===================================
class Jarvis(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("J.A.R.V.I.S.")
        self.configure(bg=BG)
        self.geometry("1100x700")
        self.minsize(900, 600)

        self.ui_q = queue.Queue()
        self.brain = Brain()
        self.speaker = Speaker(self._set_speaking)
        self.listening = False
        self.speaking = False
        self.angle = 0.0
        self.pulse = 0.0
        self.wake_mode = True      # require "Hey Jarvis"
        self.awake_until = 0.0     # follow-up window after wake word
        self.pending = None        # action waiting for "confirm"
        self.model3d = None        # model shown on the HUD
        self.rot = 0.0
        self.screen_stop = threading.Event()   # set to abort a screen-control task
        self.screen_busy = False

        self._build_ui()
        self.after(50, self._tick)
        self.after(40, self._animate)

        mode = "AI core online." if self.brain.online else \
            "Running in offline-lite mode. Set ANTHROPIC_API_KEY for full intelligence."
        self.log("JARVIS", f"Good day. All systems ready. {mode}")
        self.speaker.say("Good day. All systems are ready.")
        if sr is None:
            self.log("SYSTEM", "Voice input disabled: install SpeechRecognition and PyAudio.")
        else:
            self.toggle_listen()

    # ---------------------------------- layout ---------------------------------
    def _build_ui(self):
        left = tk.Frame(self, bg=BG)
        left.pack(side="left", fill="both", expand=True)
        right = tk.Frame(self, bg=PANEL, width=420, highlightbackground=DIM, highlightthickness=1)
        right.pack(side="right", fill="y")
        right.pack_propagate(False)

        tk.Label(left, text="J . A . R . V . I . S", bg=BG, fg=CYAN,
                 font=("Consolas", 22, "bold")).pack(pady=(14, 0))
        self.status = tk.Label(left, text="STANDBY", bg=BG, fg=BLUE, font=("Consolas", 11))
        self.status.pack()
        self.canvas = tk.Canvas(left, bg=BG, highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)

        bar = tk.Frame(left, bg=BG)
        bar.pack(fill="x", padx=16, pady=14)
        self.entry = tk.Entry(bar, bg=PANEL, fg=TEXT, insertbackground=CYAN,
                              font=("Consolas", 13), relief="flat",
                              highlightbackground=DIM, highlightcolor=CYAN, highlightthickness=1)
        self.entry.pack(side="left", fill="x", expand=True, ipady=8)
        self.entry.bind("<Return>", lambda e: self.submit_text())
        self.entry.focus_set()
        self._btn(bar, "SEND", self.submit_text).pack(side="left", padx=(8, 0))
        self.mic_btn = self._btn(bar, "MIC: OFF", self.toggle_listen)
        self.mic_btn.pack(side="left", padx=(8, 0))
        self.wake_btn = self._btn(bar, "WAKE: ON", self.toggle_wake)
        self.wake_btn.pack(side="left", padx=(8, 0))

        # right panel
        tk.Label(right, text="// CONSOLE", bg=PANEL, fg=CYAN, font=("Consolas", 12, "bold")).pack(anchor="w", padx=12, pady=(10, 4))
        self.logbox = tk.Text(right, bg=BG, fg=TEXT, font=("Consolas", 10), wrap="word",
                              relief="flat", state="disabled", height=20)
        self.logbox.pack(fill="both", expand=True, padx=10)
        self.logbox.tag_config("JARVIS", foreground=CYAN)
        self.logbox.tag_config("YOU", foreground="#ffffff")
        self.logbox.tag_config("SYSTEM", foreground="#ffb347")

        tk.Label(right, text="// DOCUMENT UPLOAD", bg=PANEL, fg=CYAN, font=("Consolas", 12, "bold")).pack(anchor="w", padx=12, pady=(10, 4))
        self.doclist = tk.Listbox(right, bg=BG, fg=TEXT, font=("Consolas", 10), height=5,
                                  relief="flat", selectbackground=DIM)
        self.doclist.pack(fill="x", padx=10)
        row = tk.Frame(right, bg=PANEL)
        row.pack(fill="x", padx=10, pady=8)
        self._btn(row, "UPLOAD", self.upload).pack(side="left")
        self._btn(row, "REMOVE", self.remove_doc).pack(side="left", padx=6)
        self._btn(row, "OUTPUT", lambda: open_file(OUTPUT_DIR)).pack(side="left")

    def _btn(self, parent, text, cmd):
        return tk.Button(parent, text=text, command=cmd, bg=PANEL, fg=CYAN, activebackground=BLUE,
                         activeforeground="#fff", relief="flat", font=("Consolas", 10, "bold"),
                         padx=12, pady=6, highlightbackground=CYAN, highlightthickness=1, cursor="hand2")

    # -------------------------------- HUD animation ----------------------------
    def _animate(self):
        c = self.canvas
        c.delete("all")
        w, h = c.winfo_width(), c.winfo_height()
        cx, cy = w / 2, h / 2
        base = min(w, h) * 0.36
        self.angle = (self.angle + (4 if self.speaking else 1.6)) % 360
        self.pulse += 0.15
        amp = (math.sin(self.pulse * 2) * 10 + 10) if self.speaking else (math.sin(self.pulse) * 3)
        if self.listening and not self.speaking:
            amp += 4

        for i, (r, wd, col) in enumerate([(1.0, 3, CYAN), (0.82, 2, BLUE), (0.64, 4, CYAN), (0.46, 2, BLUE)]):
            rad = base * r + amp * (0.3 + i * 0.1)
            direction = 1 if i % 2 == 0 else -1
            start = self.angle * direction + i * 50
            for k in range(3):
                c.create_arc(cx - rad, cy - rad, cx + rad, cy + rad,
                             start=start + k * 120, extent=80, style="arc", outline=col, width=wd)
        for r in (base * 1.12, base * 0.92):
            c.create_oval(cx - r, cy - r, cx + r, cy + r, outline=DIM, width=1)
        # ticks
        for a in range(0, 360, 10):
            rad_a = math.radians(a + self.angle * 0.3)
            r1, r2 = base * 1.12, base * 1.18
            c.create_line(cx + r1 * math.cos(rad_a), cy + r1 * math.sin(rad_a),
                          cx + r2 * math.cos(rad_a), cy + r2 * math.sin(rad_a), fill=DIM)
        # core
        core = base * 0.22 + amp
        for j in range(5, 0, -1):
            rr = core + j * 5
            c.create_oval(cx - rr, cy - rr, cx + rr, cy + rr, outline=DIM if j > 1 else CYAN, width=1)
        c.create_oval(cx - core, cy - core, cx + core, cy + core, fill=CYAN if self.speaking else BLUE, outline="")
        # rotating 3D wireframe of the last generated model
        if self.model3d is not None:
            v, e = self.model3d["verts"], self.model3d["edges"]
            r0 = base * 0.5
            c.create_oval(cx - r0, cy - r0, cx + r0, cy + r0, fill=BG, outline=CYAN)
            self.rot += 0.05
            cr, sr_ = math.cos(self.rot), math.sin(self.rot)
            x = v[:, 0] * cr + v[:, 2] * sr_
            z = -v[:, 0] * sr_ + v[:, 2] * cr
            y = v[:, 1] * 0.94 - z * 0.34
            s = base * 0.42
            px, py = cx + x * s, cy - y * s
            for a, b in e:
                c.create_line(px[a], py[a], px[b], py[b], fill=CYAN)
            c.create_text(cx, cy + base * 0.58, text=self.model3d["name"].upper(), fill=BLUE, font=("Consolas", 10))
        c.create_text(cx, cy + base * 1.35, text=datetime.datetime.now().strftime("%A  %d %b %Y   %H:%M:%S"),
                      fill=BLUE, font=("Consolas", 12))
        self.after(40, self._animate)

    # ---------------------------------- helpers --------------------------------
    def log(self, who, msg):
        self.ui_q.put(("log", who, msg))

    def _set_speaking(self, state):
        self.speaking = state
        self.ui_q.put(("status", None, None))

    def _refresh_status(self):
        if self.speaking:
            s = "SPEAKING"
        elif self.listening and self.wake_mode and time.time() > self.awake_until:
            s = "SAY 'HEY JARVIS'"
        elif self.listening:
            s = "LISTENING..."
        else:
            s = "STANDBY"
        if self.status.cget("text") != s:
            self.status.config(text=s)
        self.mic_btn.config(text="MIC: ON" if self.listening else "MIC: OFF")
        self.wake_btn.config(text="WAKE: ON" if self.wake_mode else "WAKE: OFF")

    def _tick(self):
        try:
            while True:
                kind, a, b = self.ui_q.get_nowait()
                if kind == "log":
                    self.logbox.config(state="normal")
                    self.logbox.insert("end", f"{a}> ", a)
                    self.logbox.insert("end", b + "\n\n")
                    self.logbox.see("end")
                    self.logbox.config(state="disabled")
                elif kind == "status":
                    self._refresh_status()
                elif kind == "docs":
                    self.doclist.delete(0, "end")
                    for n in self.brain.docs:
                        self.doclist.insert("end", n)
        except queue.Empty:
            pass
        self._refresh_status()
        self.after(50, self._tick)

    def respond(self, text):
        self.log("JARVIS", text)
        self.speaker.say(text)

    # ------------------------------------ input --------------------------------
    def submit_text(self):
        text = self.entry.get().strip()
        if not text:
            return
        self.entry.delete(0, "end")
        self.log("YOU", text)
        threading.Thread(target=self.handle, args=(text,), daemon=True).start()

    def toggle_listen(self):
        if sr is None:
            self.log("SYSTEM", "Install SpeechRecognition + PyAudio for voice input.")
            return
        self.listening = not self.listening
        self._refresh_status()
        if self.listening:
            threading.Thread(target=self._listen_loop, daemon=True).start()

    def toggle_wake(self):
        self.wake_mode = not self.wake_mode
        self.log("SYSTEM", "Wake word ON: say 'Hey Jarvis' first." if self.wake_mode
                 else "Wake word OFF: I respond to everything I hear.")

    def _listen_loop(self):
        rec = sr.Recognizer()
        rec.dynamic_energy_threshold = True
        try:
            mic = sr.Microphone()
        except Exception as e:
            self.log("SYSTEM", f"Microphone error: {e}")
            self.listening = False
            self.ui_q.put(("status", None, None))
            return
        with mic as source:
            rec.adjust_for_ambient_noise(source, duration=0.8)
        while self.listening:
            if self.speaker.speaking or not self.speaker.q.empty():
                threading.Event().wait(0.3)  # don't hear myself
                continue
            try:
                with mic as source:
                    audio = rec.listen(source, timeout=3, phrase_time_limit=12)
                text = rec.recognize_google(audio)
            except sr.WaitTimeoutError:
                continue
            except sr.UnknownValueError:
                continue
            except Exception as e:
                self.log("SYSTEM", f"Speech service error: {e}")
                threading.Event().wait(2)
                continue
            now = time.time()
            m = re.search(r"\bjarvis\b[,.!? ]*(.*)", text, flags=re.I)
            if m:
                text = m.group(1).strip()
                if not text:  # just the wake word
                    self.awake_until = now + 25
                    self.respond("Yes, sir?")
                    continue
            elif self.wake_mode and now > self.awake_until:
                continue  # ignore background chatter until woken
            self.log("YOU", text)
            self.handle(text)
            self.awake_until = time.time() + 25  # keep listening for follow-ups

    # ------------------------------ documents (UI) -----------------------------
    def upload(self):
        paths = filedialog.askopenfilenames(
            title="Upload documents",
            filetypes=[("Documents", "*.pdf *.docx *.xlsx *.pptx *.txt *.md *.csv *.json"), ("All", "*.*")])
        for p in paths:
            threading.Thread(target=self._load_doc, args=(p,), daemon=True).start()

    def _load_doc(self, path):
        name = os.path.basename(path)
        self.brain.docs[name] = read_document(path)
        self.ui_q.put(("docs", None, None))
        self.respond(f"{name} loaded. You can now ask me questions about it.")

    def remove_doc(self):
        sel = self.doclist.curselection()
        if sel:
            self.brain.docs.pop(self.doclist.get(sel[0]), None)
            self.ui_q.put(("docs", None, None))

    # ----------------------------- command interpreter -------------------------
    def _look(self, question):
        """Screenshot (with the JARVIS window out of the way) -> Claude vision."""
        self.after(0, self.iconify)
        time.sleep(0.9)
        try:
            return screen.describe(self.brain.client, MODEL, question)
        except Exception as e:
            return f"I couldn't read the screen: {e}"
        finally:
            self.after(0, self.deiconify)

    def _start_screen_task(self, task):
        if self.screen_busy:
            return "I'm already working on a screen task. Say stop first."
        threading.Thread(target=self._run_screen_task, args=(task,), daemon=True).start()
        return "Starting. Say stop, or move the mouse to a screen corner, to abort."

    def _run_screen_task(self, task):
        self.screen_busy = True
        self.screen_stop.clear()
        self.after(0, self.iconify)
        time.sleep(0.9)
        try:
            result = screen.run_task(self.brain.client, MODEL, task,
                                     log=lambda s: self.log("SYSTEM", s), stop=self.screen_stop)
        except Exception as e:
            result = f"The screen task stopped: {e}"
        finally:
            self.screen_busy = False
            self.after(0, self.deiconify)
        self.respond(result)

    def ask_confirm(self, desc, fn):
        self.pending = fn
        self.respond(f"{desc} Say confirm to proceed, or cancel.")

    def handle_extra(self, t, text):
        """3D models, system control, reminders, notes, messaging. Returns True if handled."""
        R = self.respond

        # --- confirmation for risky actions ---
        if self.pending:
            fn, self.pending = self.pending, None
            if t in ("confirm", "yes", "confirmed", "do it", "proceed", "yes confirm"):
                R(fn() or "Done.")
                return True
            if t in ("cancel", "no", "stop", "abort", "never mind"):
                R("Cancelled.")
                return True

        # --- voice settings ---
        if t in ("stop talking", "be quiet", "stop speaking", "silence"):
            self.speaker.clear()
            if voices is not None:
                voices.stop()
            return True
        if voices is not None:
            m = re.search(r"(?:change|switch|set|use)\s+(?:your\s+)?voice\s*(?:to)?\s*(.*)", t)
            if m:
                if voices.set_voice(m.group(1)):
                    R(f"Voice changed to {voices.current_name()}. How do I sound?")
                else:
                    R("I don't have that voice. Try: " + ", ".join(voices.VOICES) + ".")
                return True
            if t in ("list voices", "show voices", "what voices do you have"):
                R("I can speak as: " + ", ".join(voices.VOICES) + ".")
                return True
            m = re.search(r"\b(?:speak|talk)\s+(faster|slower)\b", t)
            if m:
                voices.adjust_rate(15 if m.group(1) == "faster" else -15)
                R(f"Speaking {m.group(1)} now.")
                return True

        # --- help ---
        if t in ("help", "what can you do", "what can you do for me", "show commands"):
            R("I can answer questions, create Word, Excel, PowerPoint files and 3D models, open any app, "
              "search the web, control volume, brightness and power, take screenshots, type and press keys, "
              "find files, set reminders, take notes, check weather and system status, and read your uploaded documents.")
            return True

        # --- 3D models ---
        if t in ("hide model", "remove model", "clear model", "close model", "close the model"):
            self.model3d = None
            R("Model hidden.")
            return True
        m = re.search(r"(?:create|make|generate|design|build|model)\s+(?:me\s+)?(?:a|an|the)?\s*"
                      r"(?:3d|3 d|three d|three-d)\s*(?:model|object|design|print)?\s*(?:of|for)?\s*(.*)", t)
        if m:
            what = m.group(1).strip() or "cube"
            if model3d is None:
                R("The 3D engine is missing. Run: pip install trimesh numpy")
                return True
            R(f"Designing a 3D model of {what}.")
            res = model3d.build_model(self.brain, what)
            self.model3d = res
            webbrowser.open(pathlib.Path(res["html"]).as_uri())
            R("Your 3D model is ready. It's spinning on my display and open in the viewer. "
              "STL, OBJ and GLB files are saved in the 3D folder.")
            if res.get("note"):
                R(res["note"])
            return True

        # --- sound / display / power ---
        if len(t) < 30 and re.search(r"\b(volume|sound|louder|quieter)\b|^(un)?mute\b", t):
            if "mute" in t:
                skills.volume("mute")
                R("Done.")
            elif re.search(r"\b(up|increase|raise|louder|higher)\b", t):
                skills.volume("up")
                R("Volume up.")
            elif re.search(r"\b(down|decrease|lower|reduce|quieter)\b", t):
                skills.volume("down")
                R("Volume down.")
            else:
                R("Say volume up, volume down, or mute.")
            return True
        m = re.search(r"brightness\D*(\d{1,3})", t)
        if m:
            R(f"Brightness set to {m.group(1)} percent." if skills.brightness(m.group(1))
              else "I couldn't change the brightness on this system.")
            return True
        if re.fullmatch(r"lock(?: the)?(?: screen| computer| pc| laptop)?", t):
            R(skills.power("lock"))
            return True
        m = re.fullmatch(r"(shut ?down|restart|reboot|sleep|hibernate)(?: the)?(?: computer| pc| laptop| system)?", t)
        if m:
            action = {"shutdown": "shutdown", "shut down": "shutdown", "restart": "restart",
                      "reboot": "restart", "sleep": "sleep", "hibernate": "sleep"}[m.group(1)]
            self.ask_confirm(f"About to {action} the computer.", lambda: skills.power(action))
            return True

        # --- screen / keyboard / mouse ---
        if "screenshot" in t and len(t) < 40:
            p = skills.screenshot()
            R("Screenshot saved to your Jarvis output folder." if p else "Install pyautogui for screenshots.")
            return True
        m = re.match(r"type\s+(.+)", text, flags=re.I)
        if m:
            R("Typing." if skills.type_text(m.group(1)) else "Install pyautogui first.")
            return True
        m = re.match(r"press\s+(.+)", t)
        if m:
            R("Done." if skills.press_keys(m.group(1)) else "I couldn't press that.")
            return True
        m = re.match(r"scroll\s+(up|down)", t)
        if m:
            skills.scroll(m.group(1))
            return True
        if t in ("click", "left click", "double click"):
            skills.click(t == "double click")
            return True

        # --- screen reading / control ---
        if self.screen_busy and t in ("stop", "stop that", "cancel", "stop task", "abort", "stop the task"):
            self.screen_stop.set()
            R("Stopping.")
            return True
        if screen is not None and screen.available():
            if (len(t) < 70 and re.search(r"\b(screen|display)\b", t)
                    and re.search(r"\b(what|read|describe|look|see|analy[sz]e|summari[sz]e|explain)\b", t)):
                if not self.brain.online:
                    R("Reading the screen needs the AI key. Set ANTHROPIC_API_KEY first.")
                else:
                    R("Looking at your screen.")
                    R(self._look(text))
                return True
            m = re.match(r"(?:please\s+)?(?:take control(?: and)?|on my screen,?|on screen,?|screen task:?|"
                         r"use my screen to)\s*(.+)", t)
            c = re.match(r"(?:please\s+)?click (?:on )?(?:the )?(.+)", t)
            task = m.group(1) if m else (f"click the {c.group(1)}" if c else None)
            if task:
                if not self.brain.online:
                    R("Screen control needs the AI key. Set ANTHROPIC_API_KEY first.")
                    return True
                self.ask_confirm(f"About to take control of your mouse and keyboard to: {task}.",
                                 lambda: self._start_screen_task(task))
                return True

        # --- apps & processes ---
        m = re.match(r"(?:close|quit|kill|terminate)\s+(?:the\s+)?(?:app\s+)?(.+)", t)
        if m and m.group(1) != "jarvis":
            target = m.group(1)
            self.ask_confirm(f"About to close {target}. Unsaved work in it will be lost.",
                             lambda: skills.close_app(target))
            return True
        if t in ("list apps", "list my apps", "what apps do i have"):
            apps = skills.list_apps()
            R(f"I found {len(apps)} apps. A few: " + ", ".join(apps[:12]))
            return True
        m = re.match(r"(?:run|execute)\s+(?:the\s+)?(?:shell\s+|terminal\s+)?command\s+(.+)", text, flags=re.I)
        if m:
            cmd = m.group(1)
            self.ask_confirm(f"About to run the command: {cmd}.", lambda: skills.run_shell(cmd))
            return True

        # --- information ---
        if len(t) < 40 and re.search(r"\b(battery|cpu|ram|disk space|system status|system info)\b", t):
            R(skills.sys_status())
            return True
        if len(t) < 60 and re.search(r"\bweather\b", t):
            c = re.search(r"\b(?:in|at|for) ([a-z ]+?)(?: today| now| right now)?$", t)
            R(skills.weather(c.group(1) if c else ""))
            return True
        m = re.match(r"(?:find|locate|search for)\s+(?:the\s+)?(?:file|document)\s+(.+)", t)
        if m:
            found = skills.find_files(m.group(1))
            if found:
                open_file(found[0])
                R(f"Found {len(found)} match{'es' if len(found) > 1 else ''}. Opening {os.path.basename(found[0])}.")
            else:
                R("I couldn't find a file with that name.")
            return True

        # --- reminders / notes / messaging ---
        rem = skills.parse_reminder(t)
        if rem:
            secs, msg = rem
            timer = threading.Timer(secs, lambda: R(f"Reminder: {msg}"))
            timer.daemon = True
            timer.start()
            R(f"Okay, I'll remind you in {skills.fmt_secs(secs)}.")
            return True
        m = re.match(r"(?:note down|take a note|make a note|remember that)\s+(.+)", text, flags=re.I)
        if m:
            skills.add_note(m.group(1))
            R("Noted.")
            return True
        if t in ("read my notes", "show my notes", "what are my notes"):
            R(skills.read_notes())
            return True
        m = re.search(r"whatsapp (?:message )?to (\+?\d[\d ]{6,})\s*(?:saying|that|message)?\s*(.*)", text, flags=re.I)
        if m:
            webbrowser.open(skills.whatsapp_url(m.group(1), m.group(2)))
            R("WhatsApp is open with your message ready. Press send.")
            return True
        m = re.search(r"email to (\S+@\S+)\s*(?:saying|about|that)?\s*(.*)", text, flags=re.I)
        if m:
            webbrowser.open(skills.mailto_url(m.group(1), m.group(2)))
            R("Your mail app is open with the draft ready. Press send.")
            return True
        return False

    def handle(self, text):
        t = text.lower().strip().rstrip(".?!")
        try:
            # exit
            if t in ("exit", "quit", "shutdown jarvis", "goodbye", "go to sleep"):
                self.respond("Goodbye.")
                threading.Event().wait(1.5)
                os._exit(0)

            if self.handle_extra(t, text):
                return
            # time / date
            if re.search(r"\b(what('s| is) the )?time\b", t) and len(t) < 30:
                return self.respond("It is " + datetime.datetime.now().strftime("%I:%M %p") + ".")
            if re.search(r"\b(date|today)\b", t) and len(t) < 30:
                return self.respond("Today is " + datetime.datetime.now().strftime("%A, %B %d, %Y") + ".")

            # create office documents
            m = re.search(r"(?:create|make|generate|write|build)\s+(?:me\s+)?(?:a|an|the)?\s*"
                          r"(word|document|doc|excel|spreadsheet|sheet|powerpoint|power point|ppt|presentation|slides?)"
                          r"(?:\s+(?:file|document))?\s*(?:on|about|for|of|called|named)?\s*(.*)", t)
            if m:
                kind, topic = m.group(1), m.group(2).strip() or "untitled"
                self.respond(f"Creating your {kind} on {topic}. One moment.")
                if kind in ("word", "document", "doc"):
                    path = create_word(self.brain, topic)
                elif kind in ("excel", "spreadsheet", "sheet"):
                    path = create_excel(self.brain, topic)
                else:
                    path = create_ppt(self.brain, topic)
                open_file(path)
                return self.respond(f"Done. Saved as {os.path.basename(path)} in your Jarvis output folder.")

            # open app
            m = re.match(r"(?:please\s+)?(?:open|launch|start|run)\s+(.+)", t)
            if m:
                target = m.group(1).strip()
                if re.match(r"^(https?://|www\.)", target):
                    webbrowser.open(target if target.startswith("http") else "https://" + target)
                    return self.respond("Opening the website.")
                if re.search(r"\.(com|org|net|in|io)$", target):
                    webbrowser.open("https://" + target)
                    return self.respond(f"Opening {target}.")
                if target in ("output folder", "my documents", "documents"):
                    open_file(OUTPUT_DIR)
                    return self.respond("Opening your output folder.")
                if skills.open_any_app(target, WIN_ALIASES):
                    return self.respond(f"Opening {target}.")
                return self.respond(f"I couldn't find an app called {target}.")

            # youtube
            m = re.match(r"(?:play|watch)\s+(.+?)(?:\s+on youtube)?$", t)
            if m:
                webbrowser.open("https://www.youtube.com/results?search_query=" + urllib.parse.quote(m.group(1)))
                return self.respond(f"Searching YouTube for {m.group(1)}.")

            # explicit google search
            m = re.match(r"(?:google|search(?: google)?(?: for)?|look up)\s+(.+)", t)
            if m:
                q = m.group(1)
                webbrowser.open("https://www.google.com/search?q=" + urllib.parse.quote(q))
                return self.respond(f"Searching Google for {q}.")

            # background web research (no browser window)
            m = re.match(r"(?:research|find out|search the web for|search the world for)\s+(.+)", t)
            if m:
                self.respond("Searching the web in the background.")
                return self.respond(self.brain.ask(m.group(1)) if self.brain.online else web_answer(m.group(1)))

            if t in ("clear", "clear screen", "clear chat"):
                self.brain.history.clear()
                return self.respond("Memory cleared.")

            # otherwise: general question
            self.respond(self.brain.ask(text))
        except Exception as e:
            self.respond(f"Sorry, something went wrong: {e}")


if __name__ == "__main__":
    Jarvis().mainloop()
