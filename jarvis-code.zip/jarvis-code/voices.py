"""Custom voices for JARVIS.

Engines, tried in this order:
  1. ElevenLabs  - if ELEVENLABS_API_KEY and ELEVENLABS_VOICE_ID are set (your own cloned/custom voice)
  2. edge-tts    - free Microsoft neural voices (needs internet)
  3. pyttsx3     - offline system voice (handled by jarvis.py as the last fallback)
Playback uses pygame.
"""
import os
import re
import json
import asyncio
import tempfile

import requests

try:
    import edge_tts
except Exception:
    edge_tts = None
try:
    os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
    import pygame
except Exception:
    pygame = None

SETTINGS = os.path.join(os.path.expanduser("~"), "Documents", "Jarvis_Output", "voice.json")
os.makedirs(os.path.dirname(SETTINGS), exist_ok=True)

VOICES = {
    "british": "en-GB-RyanNeural",
    "british female": "en-GB-SoniaNeural",
    "american": "en-US-GuyNeural",
    "american female": "en-US-AriaNeural",
    "indian": "en-IN-PrabhatNeural",
    "indian female": "en-IN-NeerjaNeural",
    "australian": "en-AU-WilliamNeural",
    "australian female": "en-AU-NatashaNeural",
}
DEFAULT = {"voice": "british", "rate": 5, "pitch": -4}  # slightly brisk, slightly deeper = JARVIS-like


def load():
    try:
        with open(SETTINGS, encoding="utf-8") as f:
            return {**DEFAULT, **json.load(f)}
    except Exception:
        return dict(DEFAULT)


def save(s):
    try:
        with open(SETTINGS, "w", encoding="utf-8") as f:
            json.dump(s, f)
    except Exception:
        pass


def _eleven():
    return os.environ.get("ELEVENLABS_API_KEY") and os.environ.get("ELEVENLABS_VOICE_ID")


def available():
    return pygame is not None and (edge_tts is not None or bool(_eleven()))


def _tokens(key):
    return set(key.split()) | ({"male"} if "female" not in key else set())


def set_voice(name):
    """Accepts 'british', 'indian female', 'female', or a raw edge voice like en-US-JennyNeural."""
    name = name.strip().lower()
    s = load()
    raw = re.fullmatch(r"([a-z]{2})-([a-z]{2})-(\w+?)neural", name)
    if raw:  # restore the casing edge-tts expects, e.g. en-IN-NeerjaNeural
        s["voice"] = f"{raw.group(1)}-{raw.group(2).upper()}-{raw.group(3).capitalize()}Neural"
        save(s)
        return True
    want = set(name.split())
    best, score = None, 0
    for key in VOICES:
        sc = len(want & _tokens(key))
        if sc > score:
            best, score = key, sc
    if not best:
        return False
    s["voice"] = best
    save(s)
    return True


def current_name():
    return load()["voice"]


def adjust_rate(delta):
    s = load()
    s["rate"] = max(-50, min(50, s["rate"] + delta))
    save(s)
    return s["rate"]


def _play(path):
    pygame.mixer.init()
    pygame.mixer.music.load(path)
    pygame.mixer.music.play()
    while pygame.mixer.music.get_busy():
        pygame.time.wait(50)
    try:
        pygame.mixer.music.unload()
    except Exception:
        pass


def stop():
    try:
        pygame.mixer.music.stop()
    except Exception:
        pass


def _synth_edge(text, s, path):
    voice = VOICES.get(s["voice"], s["voice"])
    comm = edge_tts.Communicate(text, voice, rate=f"{s['rate']:+d}%", pitch=f"{s['pitch']:+d}Hz")
    asyncio.run(comm.save(path))


def _synth_eleven(text, path):
    r = requests.post(
        f"https://api.elevenlabs.io/v1/text-to-speech/{os.environ['ELEVENLABS_VOICE_ID']}",
        headers={"xi-api-key": os.environ["ELEVENLABS_API_KEY"], "Content-Type": "application/json"},
        json={"text": text, "model_id": "eleven_multilingual_v2"}, timeout=30)
    r.raise_for_status()
    with open(path, "wb") as f:
        f.write(r.content)


def speak(text):
    """Blocks until finished. Raises on failure so the caller can fall back to the offline voice."""
    s = load()
    fd, path = tempfile.mkstemp(suffix=".mp3")
    os.close(fd)
    try:
        if _eleven():
            try:
                _synth_eleven(text, path)
            except Exception:
                if edge_tts is None:
                    raise
                _synth_edge(text, s, path)
        else:
            _synth_edge(text, s, path)
        _play(path)
    finally:
        try:
            os.remove(path)
        except Exception:
            pass
