# Branch guide

`main` always holds the complete, working JARVIS. Each feature was built on its own branch and merged with `--no-ff`,
so the history shows exactly what every feature added.

| Branch | Adds | New files |
|---|---|---|
| `main` | Everything below, merged | - |
| `feature/system-control-and-3d` | "Hey Jarvis" wake word, 3D model generation (GLB/STL/OBJ + viewer), open any app, volume/brightness/power, screenshots, keyboard/mouse, files, weather, reminders, notes, WhatsApp/email drafts | `skills.py`, `model3d.py` |
| `feature/custom-voice` | Neural voices (British/American/Indian/Australian), voice commands, optional ElevenLabs cloned voice | `voices.py` |
| `feature/screen-control` | "What's on my screen?", click/type tasks on the screen with confirm + stop | `screen.py` |

The first commit on `main` is the core assistant: blue HUD, voice in/out, typed commands, document upload,
Word/Excel/PowerPoint creation, web search.

## Handy commands
```
git log --graph --oneline --all        # see the history
git checkout feature/custom-voice      # look at a feature branch
git checkout main                      # back to the full version
git diff main~1 main                   # what the last merge changed
```

## Push to your own GitHub
```
git remote add origin https://github.com/<you>/jarvis.git
git push -u origin --all
```
