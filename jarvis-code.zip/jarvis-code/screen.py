"""Screen reading and screen control for JARVIS.

describe(): screenshot -> Claude vision -> spoken description.
run_task(): loop of  screenshot -> Claude picks ONE action (click/type/key/scroll) -> execute  until done.
Safety: confirmation happens in jarvis.py before a task starts, a step cap, a stop flag,
and pyautogui's fail-safe (move the mouse to a screen corner to abort).
"""
import io
import re
import json
import time
import base64

try:
    import pyautogui
    pyautogui.PAUSE = 0.1
except Exception:
    pyautogui = None

MAX_W = 1280

SYSTEM = (
    "You control a computer by looking at screenshots and replying with exactly ONE next action as JSON. "
    'Actions: {"action":"click","x":int,"y":int} | {"action":"double_click","x":int,"y":int} | '
    '{"action":"right_click","x":int,"y":int} | {"action":"type","text":str} | '
    '{"action":"key","keys":"ctrl+l"} | {"action":"scroll","direction":"up|down"} | {"action":"wait"} | '
    '{"action":"done","message":"short spoken summary of the result"}. '
    "x,y are pixel coordinates within the screenshot you are given. Include a short field \"why\". "
    "Reply with ONLY the JSON. Finish with done as soon as the task is complete or if it cannot be done. "
    "Never type passwords, payment details or one-time codes, and never confirm purchases, deletions, "
    "or sending messages unless the task explicitly asks for it; if a step needs that, finish with done "
    "and explain what is left for the user."
)

DESCRIBE_SYSTEM = (
    "You are JARVIS reading the user's screen. Answer in 1-4 short spoken sentences, no markdown. "
    "Do not read out passwords, card numbers or other secrets."
)

_KEYMAP = {"control": "ctrl", "windows": "win", "return": "enter", "escape": "esc", "cmd": "command"}


def available():
    return pyautogui is not None


def capture():
    """Returns (base64_png, (w, h) of the image sent, (sw, sh) of the real screen in click coordinates)."""
    img = pyautogui.screenshot()
    sw, sh = pyautogui.size()
    scale = min(1.0, MAX_W / img.width)
    if scale < 1.0:
        img = img.resize((int(img.width * scale), int(img.height * scale)))
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return base64.b64encode(buf.getvalue()).decode(), img.size, (sw, sh)


def _image_block(b64):
    return {"type": "image", "source": {"type": "base64", "media_type": "image/png", "data": b64}}


def describe(client, model, question):
    b64, _, _ = capture()
    resp = client.messages.create(
        model=model, max_tokens=500, system=DESCRIBE_SYSTEM,
        messages=[{"role": "user", "content": [_image_block(b64), {"type": "text", "text": question}]}])
    return resp.content[0].text.strip()


def _parse(raw):
    m = re.search(r"\{.*\}", raw, flags=re.S)
    if not m:
        return None
    try:
        return json.loads(m.group(0))
    except Exception:
        return None


def _do(act, w, h, sw, sh):
    a = act.get("action")
    if a in ("click", "double_click", "right_click"):
        x = max(0, min(sw - 1, float(act["x"]) * sw / w))
        y = max(0, min(sh - 1, float(act["y"]) * sh / h))
        if a == "click":
            pyautogui.click(x, y)
        elif a == "double_click":
            pyautogui.doubleClick(x, y)
        else:
            pyautogui.rightClick(x, y)
    elif a == "type":
        pyautogui.write(str(act.get("text", "")), interval=0.02)
    elif a == "key":
        keys = [_KEYMAP.get(k.strip().lower(), k.strip().lower()) for k in str(act.get("keys", "")).split("+")]
        keys = [k for k in keys if k]
        if keys:
            pyautogui.hotkey(*keys)
    elif a == "scroll":
        pyautogui.scroll(600 if act.get("direction") == "up" else -600)
    elif a == "wait":
        time.sleep(2)


def run_task(client, model, task, log, stop, max_steps=12):
    """Runs until done, stopped, or out of steps. Returns the sentence to speak."""
    history = []
    for step in range(1, max_steps + 1):
        if stop.is_set():
            return "Stopped."
        try:
            b64, (w, h), (sw, sh) = capture()
            text = (f"Task: {task}\nScreenshot size: {w}x{h}.\n"
                    f"Actions so far: {history[-6:] or 'none'}\nWhat is the next single action?")
            resp = client.messages.create(
                model=model, max_tokens=300, system=SYSTEM,
                messages=[{"role": "user", "content": [_image_block(b64), {"type": "text", "text": text}]}])
            act = _parse(resp.content[0].text)
            if not act:
                history.append("(unreadable reply)")
                continue
            log(f"Step {step}: {act.get('action')} - {act.get('why', '')}")
            if act.get("action") == "done":
                return act.get("message") or "Done."
            _do(act, w, h, sw, sh)
            history.append(f"{act.get('action')} ({act.get('why', '')})")
        except Exception as e:
            if type(e).__name__ == "FailSafeException":
                return "Aborted. Mouse failsafe triggered."
            return f"I hit a problem: {e}"
        time.sleep(1.2)
    return "I ran out of steps before finishing. Tell me to continue if you want me to keep going."
